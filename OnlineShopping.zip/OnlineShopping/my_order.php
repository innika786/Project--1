<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/index.css">
 	<script src='js/jquery.min.js'></script>
	<style>
		.update_profile_container{
			overflow: hidden;
			margin: auto;
			padding: 1%;
		}
		.update_profile_container a{
			float: right;
			margin: 0% 17%;
		}

		.update_pro_table{
			width: 70%;
			vertical-align: left;
			border: none;
			margin-left: 15%;
			padding: 2%;

		}

		.update_pro_table tr:nth-child(even) {background-color: #f2f2f2;}

		.update_pro_table th{
			text-align: left;
			padding: 3%;
		}

		.update_pro_table td{
			text-align: left;
			padding: 3%;
		}

		.update_pro_table td a{
			text-decoration: none;
		}
	</style>
</head>
<body>
	<?php
		include 'includes/header.php';
		$result=get_order_info();
	?>
	<div class="update_profile_container">
		<a href="my_order.php">Refresh Page</a>
		<table class="update_pro_table"  cellspacing="0" cellpadding="0">
			<tr>
				<th>SL</th>
				<th>Order Date</th>
				<th>Order ID</th>
				<th>Total Amount</th>
				<th>Order Status</th>
				<th></th>
			</tr>
			<?php
			$sl=1;
			while ($row=fetch_array($result)) {
				if ($row['approve_status']==1) {
			?>
			<tr style="background: rgba(110,196,118,0.3);">
				<td><?php echo $sl++; ?></td>
				<td><?php echo $row['order_date']; ?></td>
				<td><?php echo $row['order_id']; ?></td>
				<td><?php echo $row['total_amount']; ?></td>
				<td>
					<?php 
					if ($row['approve_status']==1) {
						echo "Confirmed";
					}
					else
					{
						echo "Pending";
					}

					?>
						
				</td>
				<td><a href="" onclick="MyWindow=window.open('indivisual_order_details.php?order_id=<?php echo $row['order_id']; ?>', 'MyWindow', 'width=800, height=700'); return false;">Details</a></td>
			</tr>
			<?php
			}
			else
			{ ?>
			<tr>
				<td><?php echo $sl++; ?></td>
				<td><?php echo $row['order_date']; ?></td>
				<td><?php echo $row['order_id']; ?></td>
				<td><?php echo $row['total_amount']; ?></td>
				<td>
					<?php 
					if ($row['approve_status']==1) {
						echo "Confirmed";
					}
					else
					{
						echo "Pending";
					}

					?>
						
				</td>
				<td><a href="" onclick="MyWindow=window.open('indivisual_order_details.php?order_id=<?php echo $row['order_id']; ?>', 'MyWindow', 'width=800, height=700'); return false;">Details</a></td>
			</tr>
			<?php
			}
			}
			?>

		</table>
	</div>
</body>
</html>