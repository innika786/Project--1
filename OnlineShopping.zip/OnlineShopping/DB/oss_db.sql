-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2019 at 05:01 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oss_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(225) NOT NULL,
  `admin_name` varchar(225) NOT NULL,
  `admin_id` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `contact_num` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `admin_id`, `email`, `password`, `contact_num`) VALUES
(6, 'Innika Ferdoush', 'innika02', 'innika01828@gmail.com', '1234', '01828455344'),
(7, 'Ferdoushi', 'ferdoushi01', 'innika01746@gmail.com', '1234', '01828455344');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(2, 'Mobile Phone'),
(3, 'Watch'),
(5, 'Gadget'),
(6, 'Home Appliance'),
(7, 'Computer & Laptop');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `cus_id` varchar(225) NOT NULL,
  `cus_name` varchar(225) NOT NULL,
  `ship_address` text NOT NULL,
  `payment_type` varchar(225) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `total_amount` int(225) NOT NULL,
  `approve_status` int(225) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_id`, `order_date`, `cus_id`, `cus_name`, `ship_address`, `payment_type`, `transaction_id`, `total_amount`, `approve_status`) VALUES
(18, '2019-12-07', 'innika786', 'Innika Ferdoush', 'Uttara, Dhaka.', 'cash on delivery', 'N/A', 50040, 1),
(19, '2019-12-09', 'innika786', 'Innika Ferdoush', 'Uttara, Dhaka.', 'cash on delivery', 'N/A', 125040, 0),
(20, '2019-12-09', 'innika786', 'Innika Ferdoush', 'Uttara, Dhaka.', 'B-Kash', '12', 86840, 0),
(21, '2019-12-11', 'innika786', 'Innika Ferdoush', 'Uttara, Dhaka.', 'B-Kash', '123', 480040, 1),
(22, '2019-12-11', 'innika786', 'Innika Ferdoush', 'Uttara, Dhaka.', 'B-Kash', '1', 21540, 1),
(23, '2019-12-22', 'innika786', 'Innika Ferdoush', 'Uttara, Dhaka.', 'cash on delivery', 'N/A', 8805, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `oitem_id` int(11) NOT NULL,
  `order_id` varchar(225) NOT NULL,
  `product_id` varchar(225) NOT NULL,
  `product_name` varchar(225) NOT NULL,
  `quantity` int(225) NOT NULL,
  `unit_price` int(255) NOT NULL,
  `sub_total` int(225) NOT NULL,
  `approve_status` int(225) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`oitem_id`, `order_id`, `product_id`, `product_name`, `quantity`, `unit_price`, `sub_total`, `approve_status`) VALUES
(1, '18', '6', 'Headphone', 1, 850, 850, 1),
(4, '18', '1', 'Samsung 32" LED TV', 1, 14000, 14000, 1),
(5, '4', '6', 'Head Phone', 1, 400, 400, 1),
(6, '5', '1', 'Samsung LED Television', 2, 14000, 28000, 1),
(8, '7', '6', 'Head Phone', 1, 400, 400, 1),
(11, '10', '3', 'Smart Watch C1', 1, 1400, 1400, 1),
(13, '12', '4', 'LCD Television', 1, 11000, 11000, 1),
(14, '13', '21', 'DAIKIN AC', 1, 50000, 50000, 1),
(15, '14', '21', 'DAIKIN AC', 1, 50000, 50000, 1),
(16, '15', '33', 'WALTON Olvio MM5J', 1, 1550, 1550, 1),
(19, '17', '50', 'Sony SRS-XB21 Portable Wireless Bluetooth Speaker ', 1, 1200, 1200, 1),
(20, '17', '2', 'Smart Watch V8', 3, 2300, 6900, 1),
(21, '18', '9', 'HP Pavilion Laptop ', 1, 50000, 50000, 1),
(22, '19', '5', 'HITACHI Refrigerator ', 1, 125000, 125000, 0),
(23, '20', '4', 'LG LED TV ', 1, 46300, 46300, 0),
(24, '20', '6', 'Acer Core i5 7th Gen Brand PC ', 1, 40500, 40500, 0),
(25, '21', '10', 'Air Con Electronics', 4, 120000, 480000, 1),
(26, '22', '2', 'Smart Watch C1S', 1, 21500, 21500, 1),
(27, '23', '1', 'Smart Watch C1', 1, 8765, 8765, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_info`
--

CREATE TABLE `product_info` (
  `p_id` int(11) NOT NULL,
  `product_name` varchar(225) NOT NULL,
  `product_category` varchar(225) NOT NULL,
  `product_sub_category` varchar(225) NOT NULL,
  `product_details` text NOT NULL,
  `quantity` int(225) NOT NULL,
  `product_price` int(225) NOT NULL,
  `product_image` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_info`
--

INSERT INTO `product_info` (`p_id`, `product_name`, `product_category`, `product_sub_category`, `product_details`, `quantity`, `product_price`, `product_image`) VALUES
(1, 'Smart Watch C1', 'Watch', 'Smart Watch', 'khhhhhr khhgff', 14, 8765, '0.jpg'),
(2, 'Smart Watch C1S', 'Watch', 'Smart Watch', ' C1S Heart Rate Smart Bracelet Sports Watch Sleep Monitoring Call Reminder Function Smart Watch - Blue China ', 2, 21500, 'byc-led-multicolour-digital-watch-500x500.png'),
(3, 'Sony SRS-XB21 Portable Wireless Bluetooth Speaker ', 'Gadget', 'Speaker', 'Pump up any party with the Sony SRS-XB21 portable wireless party speaker with lights, Party Booster ... XB21 EXTRA BASSâ„¢ Portable BLUETOOTHÂ® Speaker', 27, 10900, 'sony-xb950b1-extra-bass-wireless-headphones-with-app-control-blue-2017-model-audio-accessory-kit.jpg'),
(4, 'LG LED TV ', 'Home Appliance', 'Television', 'Create a cinematic experience at home. LG LED TVs boast sharp images, vibrant colours, and deep blacks, plus ground-breaking technology', 7, 46300, 'LED tv 1.jpg'),
(5, 'HITACHI Refrigerator ', 'Home Appliance', 'Refrigerator', 'This page will easily guide you towards finding Hitachi Refrigerator Price in Bangladesh. Buy Dual Fan Cooling and Inverter Hitachi Refrigerator in Bangladesh at Best Electronics ', 7, 125000, 'hitachi 1.jpg'),
(6, 'Acer Core i5 7th Gen Brand PC ', 'Computer & Laptop', 'Acer Brand Computer', 'Acer aspire E5-575 laptop has Intel core i5-7200U processor, 4 GB DDR4 RAM, 1 TB SATA HDD, 15.6 inch HD Acer CineCrystal LED LCD display, Intel HD graphics 620, webcam, DVD R/W, gigabit LAN, bluetooth, wi-fi, card reader, 4 cell battery', 3, 40500, 'Acer-Nitro-Spin-5-380.png'),
(7, 'Refurbished HP 15-ay137cl Notebook ', 'Computer & Laptop', 'hp brand', 'This item is REFURBISHED. 7th-generation IntelÂ® Coreâ„¢ i7-7500U Processor15.6" diagonal HD SVA BrightView WLED-backlit display16GB DDR4 SDRAM / 1TB Hard DriveFront-facing HP TrueVision', 8, 50000, 'hp laptop.jpg'),
(8, 'Trekz Titanium HeadPhone', 'Gadget', 'Head Phone', 'AfterShokz Titanium is an excellent Bluetooth product for those interested in entering the open-ear headphone world. Unlike traditional headphones', 10, 1500, 'Trekz_large.jpg'),
(9, 'HP Pavilion Laptop ', 'Computer & Laptop', 'hp brand', 'Thin, light and powerful. Shop our HP Pavilion laptop family here. Learn about HP Pavilion x360 with four modes and HP Pavilion Power for multimedia', 20, 50000, '4719aa51f82685e3f878a7634d2fb326e63708a3_large.jpg'),
(10, 'Air Con Electronics', 'Home Appliance', 'AC', '\r\n        Excellent oxidation and thermal stability under severe operation.\r\n\r\n        Superb detergent-dispersant characteristics.\r\n\r\n        Prevents harmful foaming.\r\n', 13, 120000, 'giant_30974.jpg'),
(11, 'Eliteone-one-Desktop ', 'Computer & Laptop', 'hp brand', 'A computer is a programmable machine that is both electronic and digital. The actual machinery is hardware; the instructions and data is software.', 5, 84000, '510372-hp-eliteone-1000-curved-aio.jpg'),
(12, 'Brookstone 140064 Over the Ear Headphone - Blue', 'Gadget', 'Speaker', 'Find many great new & used options and get the best deals for Brookstone 140064 Over the Ear Headphone - Blue at the best online prices', 11, 5000, 's-l640.jpg'),
(13, 'Micromax Q409 Spark 4G VoLTE Dual SIM', 'Mobile Phone', 'Features Phone', '\r\n    5 in (12.7 cm) IPS LCD Capacitive Touchscreen\r\n    Android 7.0 Nougat OS\r\n    1.3 GHz Quad Core Processor & 1GB RAM\r\n', 12, 15070, 'micromax-q409-spark-4g-volte-dual-sim-android-mobile-phone-grey-large_32cb9510fe1d8b233ecb3a6fc4a057cc.jpg'),
(14, 'Micromax Q409 Spark 4G VoLTE Dual SIM', 'Mobile Phone', 'Features Phone', 'khjghfd khjfg', 18, 15070, 'micromax-q409-spark-4g-volte-dual-sim-android-mobile-phone-grey-large_32cb9510fe1d8b233ecb3a6fc4a057cc.jpg'),
(15, 'Micromax Q409 Spark 4G VoLTE Dual SIM', 'Mobile Phone', 'Android Mobile ', 'klhjgf', 6, 10900, 'micromax-q409-spark-4g-volte-dual-sim-android-mobile-phone-grey-large_32cb9510fe1d8b233ecb3a6fc4a057cc.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_category_id` int(11) NOT NULL,
  `category_id` varchar(225) NOT NULL,
  `sub_category_name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_category_id`, `category_id`, `sub_category_name`) VALUES
(18, '2', 'Smart Phone'),
(19, '2', 'Features Phone'),
(20, '3', 'Smart Watch'),
(21, '6', 'Television'),
(22, '6', 'Refrigerator'),
(23, '6', 'AC'),
(24, '5', 'Speaker'),
(25, '5', 'Head Phone'),
(26, '7', 'Acer Brand Computer'),
(27, '7', 'hp brand'),
(28, '3', 'Digital Watch'),
(29, '7', 'Dell brand'),
(30, '2', 'Android Mobile ');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `user_id` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `contact_num` varchar(255) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `name`, `user_id`, `password`, `email`, `contact_num`, `address`) VALUES
(1, 'Test', 'test123', '12345', 'test@test.com', '01718876654', 'Uttara'),
(3, 'Innika Ferdoush', 'innika786', '123456', 'innika01@gmail.com', '01828455344', 'Uttara, Dhaka.'),
(5, 'Innika Ferdous', 'innika09', '123456', 'innika0001@gmail.com', '01828455345', 'Azimpur, Dhaka.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`oitem_id`);

--
-- Indexes for table `product_info`
--
ALTER TABLE `product_info`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_category_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `oitem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `product_info`
--
ALTER TABLE `product_info`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
