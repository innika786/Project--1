<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Order Details</title>
        <style>
            body{

            }
            .all{
                margin-left: -39%;
            }
            .first, .first th{
                font-size:18px;
                text-align: left;
                font-family:Arial;
                
            }
            .first td{
                font-size:18px;
                text-align: left;
                padding-left:1%;
                font-family:Arial;

            }
            .second{
                width:821px;
                margin:auto;
                text-align:center;
                table-layout:fixed;
            }
            .first{
                width:400px;
                margin:auto;
                text-align:center;
                table-layout:fixed;
            }
            .second , .second tr, .second th, .second td{
                padding:20px;
                color:white;
                border:1px solid #a6d8a8;
                border-collapse:collapse;
                font-size:18px;
                font-family:Arial;
                color: black;
            }
            .first_tr{
                background:linear-gradient(top, #4caf50 0%, #4caf50 100%);
                background:-webkit-linear-gradient(top, #4caf50 0%, #4caf50 100%);
            }

          /*  .second, .second tr:hover td{
                background:#e83f33;

            }*/
          /*  .second td{
                background:linear-gradient(top, #95d097 0%, #95d097 100%);
                background:-webkit-linear-gradient(top, #95d097 0%, #95d097 100%);

            }*/
            h2{
                font-style: italic;
                font-size: 1.2em;
                color:black;
            }
           /* h1{
                width:800px;
                margin:auto;
                font-size: 2em;
                text-align:center;
                color:black;
                font-family:Arial;
                padding:20px;
            }*/
            

            center{
                font-size:25px;
                margin-top:25px;
                text-align: center;
                font-family:Arial;
                
            }
            h1 {
                background:#000;
                border-radius: 0.25em;
                color:#FFF;
                margin: 26px 240px 2em;
                padding: 0.5em 0;
                font: bold 100% sans-serif;
                letter-spacing: 0.5em;
                text-align: center;
                text-transform: uppercase;
            }
            .header-logo {
                 width: 7%;
                 margin-inline: 88%;
                 margin-top: -7%;
                }
        </style>
    </head>
    <body>       
        
        <section>
            <h1 style="margin-left: 7%;">INVOICE</h1>
        </section>
        <div class="logo-col">
            <a><img class="header-logo" src="images/logo1.png" alt=""style=""></a>
        </div>
        <div class= all>        
        <section>
            <table class="first">
                <?php
                include 'functions/init.php';
                $oid=$_GET['order_id'];
                    $cus_row= get_orderd_customer_info($oid);
                ?>
                <caption>
                    <h2>Customer Information</h2>
                </caption>
                <tr>
                    <th>Customer Name:</th>
                    <td><?php echo $cus_row['name']; ?></td>
                </tr>

                <tr>
                    <th>Customer Phone:</th>
                    <td><?php echo $cus_row['contact_num']; ?></td>
                </tr>

                <tr>
                    <th>Customer Email:</th>
                    <td><?php echo $cus_row['email']; ?></td>
                </tr>

                <tr>
                    <th>Shipping Address:</th>
                    <td><?php echo $cus_row['ship_address']; ?></td>
                </tr>

                <tr>
                    <th>Payment Type:</th>
                    <td><?php echo $cus_row['payment_type']; ?></td>
                </tr>

                <tr>
                    <th>Order Date:</th>
                    <td><?php echo $cus_row['order_date']; ?></td>
                </tr>
            </table>


            <table class="first" style="margin-inline: 67%;margin-top: -11%;">
                <caption>
                    <h2>Counter #: 1 Information</h2>
                </caption>
                <tr>
                    <th>Name:</th>
                    <td>Ferdoushi</td>
                </tr>

                <tr>
                    <th>Phone:</th>
                    <td>01904382852</td>
                </tr>

                <tr>
                    <th>Email:</th>
                    <td>innika01828@gmail.com</td>
                </tr>
                <tr>
                    <th>Address: </th>
                    <td>House-19 Road-04, <br>Jashim Uddin ,Dhaka 1230</td>
                </tr>            
            </table>

        </section>
        <section style=" margin-left: 28%;">
            <table class="second" style="margin-top: 6%;">
                <caption>
                    <h2>Product Information</h2>
                </caption>
                <tr class="first_tr">
                    <th>SL</th>
                    <th>Product Id</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total Price</th>
                </tr>
                <?php
                    $result=get_orderd_product_info($oid);
                    $sl=1;
                    $st=0;
                    while ($row= mysqli_fetch_array($result)) {
                ?>
                <tr class="p_row">
                    <td><?php echo $sl++; ?></td>
                    <td><?php echo $row['product_id']; ?></td>
                    <td><?php echo $row['product_name']; ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td><?php echo $row['unit_price']; ?></td>
                    <td><?php echo $row['sub_total']; ?></td>
                                   
                </tr>
                 <?php
                 $st += $row['sub_total'];
                    }
                ?>          
                <tr style="background:none; border-top: 3px solid #4CAF50;">

                    <td style="border: none;"></td>
                    <td style="border: none;"></td>
                    <td style="border: none;"></td>
                    <td style="border: none;"></td>
                    <td><strong>Sub Total</strong></td>
                    <td><span>&#2547;</span> <?php echo $st; ?></td>
                </tr>
                <tr style="background:none;">
                    <td style="border: none;"></td>
                    <td style="border: none;"></td>
                    <td style="border: none;"></td>
                    <td style="border: none;"></td>
                    <td><strong>Shipping Cost</strong></td>
                    <td><span>&#2547;</span>150</td>
                </tr>
                <tr style="background:none;">
                    <td style="border: none;"></td>
                    <td style="border: none;"></td>
                    <td style="border: none;"></td>
                    <td style="border: none;"></td>
                    <td><strong>Grand Total</strong></td>
                    <td><span>&#2547;</span> <?php echo $st+150; ?></td>
                </tr> 
            </table>
        </section>
        <section>
        <center>
            <a href="indivisual_order_details.php?bk=<?php echo md5("str"); ?>">Continue Shopping</a>
        </center>
        </section>

        <?php
            if (isset($_GET['bk'])) {
                echo "<script>window.close();</script>";
            }
        ?>
    </div>
    <aside>
            <h3><span contenteditable>Additional Notes</span></h3>
            <div contenteditable>
                <p>If you face any kind of problem in product you have to contact within 3 days.After 3 days it will not be changeable</p>
            </div>
        </aside>
    </body>
</html>
















