<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Product Information</title>
    <script src='js/jquery.min.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
        * {
          box-sizing: border-box;
        }

        form.example input[type=text] {
          padding: 10px;
          font-size: 17px;
          border: 1px solid grey;
          float: left;
          width: 80%;
          background: #f1f1f1;
        }

        form.example button {
          float: left;
          width: 20%;
          padding: 10px;
          background: #b9770e;
          color: white;
          font-size: 17px;
          border: 1px solid grey;
          border-left: none;
          cursor: pointer;
        }

        form.example button:hover {
          background: #4CAF50;
        }

        form.example::after {
          content: "";
          clear: both;
          display: table;
        }

            table{
                width:100%;
                margin:auto;
                text-align:center;
                table-layout:fixed;
            }
            table{
                padding:20px;
                color:black;
                border:1px solid #a6d8a8;
                border-collapse:collapse;
                font-size:18px;
                font-family:Arial;
            }
            .n_hv:hover td{
                background:#e83f33;
                
            }

            input[type=text], #select1, #select2 {
                width: 96%;
            }

            .n_hv{
                background: #6FC576;
            }


            h2{
                color:black;
            }
           /*.search_div{
            margin-left: 81%;
           }*/
        </style>
    </head>
    <body>     
        <section>
            <div class="search_div">
                <form class="example" action="/action_page.php" style="margin:auto;max-width:300px">
                      <input type="text" placeholder="Search.." name="search2">
                      <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
            <table>
                <caption>
                    <h2>Product Information</h2>
                </caption>
                <?php 
                if (isset($_GET['id'])) {
                    $p_id=$_GET['id'];
                    $sql="SELECT * FROM product_info WHERE p_id='$p_id'";
                    $result=mysqli_query($conn, $sql);
                    $p_row=mysqli_fetch_array($result);

                    $c_result=get_category();
                    $sc_result=get_sub_category();

                 ?>
                <tr>
                    <form action="" method="post">
                        <td style="width: 4%;"></td>
                        <td style="overflow: hidden; width: 9%;"><?php echo $p_row['p_id']; ?></td>
                        <input type="hidden" name="p_id" value="<?php echo $p_row['p_id']; ?>">
                        <td style="overflow: hidden; text-align: center;">
                            <input type="text" name="p_name" value="<?php echo $p_row['product_name']; ?>">
                        </td>
                        <td style="overflow: hidden; width: 9%;">
                            <input type="text" name="p_qty" value="<?php echo $p_row['quantity']; ?>" pattern="^[0-9]{1,99999999}" title="accept only positive numerical value">
                        </td>
                        <td style="overflow: hidden;">
                            <input type="text" name="p_price" value="<?php echo $p_row['product_price']; ?>" pattern="^[0-9]{1,99999999}" title="accept only positive numerical value">
                        </td>
                        <td style="overflow: hidden;">
                            <select name="select1" id="select1">
                                <option value="0"><-- Select Category --></option>
                                <?php
                                    while ($c_row=mysqli_fetch_array($c_result)) { // fetching the each row of category table
                                        $category_id=$c_row['category_id'];
                                     ?>
                                        <option value="<?php echo $c_row['category_id']; ?>" data-othervalue="<?php echo $c_row['category_name']; ?>"><?php echo $c_row['category_name']; ?></option>
                                    <?php
                                    }
                                ?>
                            </select>
                            <input type=hidden name=category id=categoryValue />
                            </td>
                        <td style="overflow: hidden;">
                            <select name="select2" id="select2">
                                <?php
                                    while ($sc_row=mysqli_fetch_array($sc_result)) { // fetching the each row of category table
                                        $category_id=$sc_row['category_id'];
                                     ?>
                                        <option value="<?php echo $sc_row['category_id']; ?>" data-othervalue="<?php echo $sc_row['sub_category_name']; ?>"><?php echo $sc_row['sub_category_name']; ?></option>
                                    <?php
                                    }
                                ?>
                            </select>
                            <input type=hidden name=subcategory id=subcategoryValue />

                            </td>
                        <td colspan="2" style="width: 15%;">
                            <button name="update_btn">Update</button>
                        </td>
                    </form>
                </tr>
                <?php
                }
                ?>
                <tr class="n_hv">
                    <th style="width: 4%;">Sl</th>
                    <th style="width: 9%;">Product Id</th>
                    <th>Product Name</th>
                    <th style="width: 9%;">Quantity</th>
                    <th>Unit Price</th>
                    <th>Category</th>
                    <th>Sub Category</th>
                    <th colspan="2" style="width: 15%;">Action</th>
                </tr>
                <?php
                $result=get_product_info();
                $sl=1;
                while ($row=mysqli_fetch_array($result)) {
                if ($row['quantity']<=5) { ?>
                    <tr style="background: #E83F33;">
                        <td style="width: 4%;"><?php echo $sl++; ?></td>
                        <td style="width: 9%"><?php echo $row['p_id']; ?></td>
                        <td><?php echo $row['product_name']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td><?php echo $row['product_price']; ?></td>
                        <td><?php echo $row['product_category']; ?></td>
                        <td><?php echo $row['product_sub_category']; ?></td>
                        <td><a style="text-decoration: none;" href="admin_dashboard.php?p_info=<?php echo md5("6"); ?>&id=<?php echo $row['p_id']; ?>">Edit</a></td>
                        <td>
                            <a style="text-decoration: none;" href="admin_dashboard.php?p_info=<?php echo md5("6"); ?>&delete_id=<?php echo $row['p_id']; ?>">Delete</a></td>
                        
                    </tr>
                <?php
                }
                else
                { ?>
                    <tr>
                        <td><?php echo $sl++; ?></td>
                        <td><?php echo $row['p_id']; ?></td>
                        <td><?php echo $row['product_name']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td><?php echo $row['product_price']; ?></td>
                        <td><?php echo $row['product_category']; ?></td>
                        <td><?php echo $row['product_sub_category']; ?></td>
                        <td><a style="text-decoration: none;" href="admin_dashboard.php?p_info=<?php echo md5("6"); ?>&id=<?php echo $row['p_id']; ?>">edit</a></td>
                        <td><a style="text-decoration: none;" href="admin_dashboard.php?p_info=<?php echo md5("6"); ?>&delete_id=<?php echo $row['p_id']; ?>">Delete</a></td>
                        
                    </tr>
                <?php
                }
                }
                ?>
            </table>
        </section>

        <?php
            if ($_SERVER['REQUEST_METHOD']=="POST") {
                if (isset($_POST['update_btn'])) {
                    $pid=$_POST['p_id'];
                    $p_name=$_POST['p_name'];

                    $c_name=$_POST['category'];
                    $sc_name=$_POST['subcategory'];

                    $p_qty=$_POST['p_qty'];
                    $p_price=$_POST['p_price'];

                    if ($_POST['select1']==0) {
                        $sql="UPDATE product_info SET product_name='$p_name', quantity='$p_qty', product_price='$p_price' WHERE p_id='$pid'";
                        
                        if (mysqli_query($conn, $sql)) {
                            echo "<script>alert('Record Updated!!'); window.location='admin_dashboard.php?p_info=1679091c5a880faf6fb5e6087eb1b2dc'</script>";
                        }
                    }
                    else{
                        $sql="UPDATE product_info SET product_name='$p_name', quantity='$p_qty', product_price='$p_price', product_category='$c_name', product_sub_category='$sc_name' WHERE p_id='$pid'";
                        
                        if (mysqli_query($conn, $sql)) {
                            echo "<script>alert('Record Updated!!'); window.location='admin_dashboard.php?p_info=1679091c5a880faf6fb5e6087eb1b2dc'</script>";
                        }
                    }
                }
            }

            if (isset($_GET['delete_id'])) {
                $pid=$_GET['delete_id'];
                $dlt_sql="DELETE FROM product_info WHERE p_id='$pid'";
                if (query($dlt_sql)) {
                        echo "<script>alert('Record Deleted!!'); window.location='admin_dashboard.php?p_info=1679091c5a880faf6fb5e6087eb1b2dc'</script>";
                }

            }
        ?>


<script>
    // script for dependent dropdown
    var $select1 = $( '#select1' ),
        $select2 = $( '#select2' ),
    $options = $select2.find( 'option' );
    
$select1.on( 'change', function() {
    $select2.html( $options.filter( '[value="' + this.value + '"]' ) );
} ).trigger( 'change' );

// script for store category dropdown value into input type 
$('#select1').change(function () {
var otherValue=$(this).find('option:selected').attr('data-othervalue');
$('#categoryValue').val(otherValue);
});

// script for store sub-category dropdown value into input type 
$('#select2').change(function () {
var otherValue=$(this).find('option:selected').attr('data-othervalue');
$('#subcategoryValue').val(otherValue);
});



</script>
    </body>
</html>
















