<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style>
		.giphy_container{
			overflow: hidden;
			margin: auto;
			padding: 1%;
		}

		.giphy_img{
			margin: -8% 16%;
		}

	</style>
</head>
<body>
	<div class="giphy_container">
		<img class="giphy_img" src="images/giphy.gif" alt="">
	</div>
</body>
</html>