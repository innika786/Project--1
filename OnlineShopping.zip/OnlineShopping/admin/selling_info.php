<!DOCTYPE html>
<html>
<head>
<style>
#selling {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#selling td, #selling th {
  border: 1px solid #ddd;
  padding: 8px;
}

#selling tr:nth-child(even){background-color: #f2f2f2;}

#selling tr:hover {background-color: #ddd;}

#selling th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
[type="date"] {
  background:#fff url(https://cdn1.iconfinder.com/data/icons/cc_mono_icon_set/blacks/16x16/calendar_2.png)  97% 50% no-repeat ;
}
[type="date"]::-webkit-inner-spin-button {
  display: none;
}
[type="date"]::-webkit-calendar-picker-indicator {
  opacity: 0;
}

/* custom styles */


input {
  border: 1px solid #c4c4c4;
  border-radius: 5px;
  background-color: #fff;
  padding: 3px 5px;
  box-shadow: inset 0 3px 6px rgba(0,0,0,0.1);
  width: 111px;
}
.vbtn {
 margin-top: -2%;
 margin-bottom: 3%;
 margin-inline: 44%;
}
.vbtn a {
    
    padding: 7px;
    cursor: pointer;
    text-decoration: none;
    font-size: 17px;
    margin-inline: 44%;
}
.vbtn a:hover {
    background-color: #4CAF50;
}
.pbtn {
	 margin-top: 2%;
	 margin-inline: 95%;
}
.pbtn a {
    
    padding: 7px;
    cursor: pointer;
    text-decoration: none;
    font-size: 17px;
    margin-inline: 44%;
}
.pbtn a:hover {
    background-color: #4CAF50;
}

</style>
</head>
<body>
	

<div class="date_box">
	<form method="post" action="">
	<label for="dateofbirth">From</label>
	<input type="date" name="datefrom" id="dateofbirth" required>

	<label for="dateofbirth">To</label>
	<input type="date" name="dateto" id="dateofbirth" required>
	<div class="vbtn">
		<button name="report_btn">View</button>
	</div>
	</form>
</div>
<div id="printableArea">
	<h1>Selling Information</h1>
	<table id="selling">
	    <tr>
		    <th>SL</th>
		    <th>Date</th>
		    <th>Order ID</th>
		    <th>Product id</th>
		    <th>Product Name</th>
		    <th>Quantity</th>
		    <th>Unit Price</th>
		    <th>Total Price</th>
		    
	    </tr>

<?php

	$g_total=0;
if (isset($_POST['report_btn'])) {
	$result1=get_date_wise_order();
	$sl=1;
	while($row1=fetch_array($result1)){
		$o_id=$row1['order_id'];
		$o_date=$row1['order_date'];

		$result=get_order_order_details($o_id);
		while ($row=fetch_array($result)) {
?>
	    <tr>
		    <td><?php echo $sl++ ?></td>
		    <td><?php echo $o_date; ?></td> 
		    <td><?php echo $o_id; ?></td> 
		    <td><?php echo $row['product_id']; ?></td>
		    <td><?php echo $row['product_name']; ?></td>  
		    <td><?php echo $row['quantity']; ?></td>
		    <td><?php echo $row['unit_price']; ?></td>
		    <td><?php echo $row['sub_total']; ?></td> 
		     
	    </tr>
	    <?php
	    $o_id="";
	    $o_date="";
	    $g_total += $row['sub_total'];
		}
				
	     } 

}?>

				<tr style="background:none;">
					<td style="border: none;"></td>
					<td style="border: none;"></td>
					<td style="border: none;"></td>
					<td style="border: none;"></td>
					<td style="border: none;"></td>
					<td style="border: none;"></td>
					<td><strong>Grand Total</strong></td>
					<td><span>&#2547;</span><?php echo $g_total; ?></td>
				</tr>
	 </table>
	 </div>
	 <div class="pbtn">

	   <input type="button" onclick="printDiv('printableArea')">
	</div>
<script>
	function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script>
</body>
</html>